#!/bin/bash

#### get_hostname

function get_hostname() {
hostname
}

#### cpu_model_name

function cpu_model_name() {

less /proc/cpuinfo | grep model
}


get_hostname
cpu_model_name



