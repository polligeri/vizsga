SET ANSI_DEFAULTS ON

SELECT modelName, dateAcquired FROM carsForSale WHERE acquisitionPrice > 8000;