SET ANSI_DEFAULTS ON

SELECT manufacturerName, headquarters, founder FROM manufacturers;