

SELECT manufacturerName, founder, foundedInYear FROM carsForSale RIGHT JOIN manufacturers On carsForSale.id = manufacturers.id WHERE foundedInYear BETWEEN 1500 AND 1914; ;
