SET ANSI_DEFAULTS ON
CREATE TABLE carsForSale (
id int PRIMARY KEY NOT NULL,
modelName varchar(100),
acquisitionPrice decimal(10),
dateAcquired	date,
manufacturer_id	int
);
CREATE TABLE manufacturers (
id int PRIMARY KEY NOT NULL,
manufacturerName	varchar(100),
founder	varchar(100),
foundedInYear	int,
headquarters	varchar(100)
);

INSERT INTO carsForSale (id, modelName, acquisitionPrice, dateAcquired,	manufacturer_id)
VALUES 
(1,	'Jetta',	13300,	'2007-01-07',	1),
(2,	'Laguna',	14700,	'2007-02-12',	2),
(3,	'Focus',	13600,	'2007-03-09',	3),
(4,	'Tico',	1100,	'2007-04-17',	4),
(5,	'Avensis',	14500,	'2007-05-04',	5),
(6,	'156',	8700,	'2007-06-23',	6),
(7,	'Passat',	22000,	'2007-07-16',	1),
(8,	'Clio',	6400,	'2007-08-22',	2),
(9,	'Fiesta',	6900,	'2007-09-11',	3),
(10,	'Cielo',	3600,	'2007-10-18',	4),
(11,	'Rav4',	24900,	'2007-11-11',	5),
(12,	'147',	7500,	'2007-12-25',	6),
(13,'Golf',	16700,	'2008-01-14',	1),
(14,'Megane',	11400,	'2008-02-24',	2),
(15,	'Mondeo',	14600,	'2008-03-18',	3);



INSERT INTO manufacturers (id,	manufacturerName,	founder,	foundedInYear,	headquarters)
VALUES 
(	1, 'Volkswagen AG',	'Kraft durch Freude',	1937,	'Wolfsburg, Germany'),
(2,	'Renault S.A.',	'Louis Renault',	1899,	'Boulogne-Billancourt, France'),
(3,	'Ford Motor Company',	'Henry Ford',	1903,	'Dearborn, Michigan, U.S.'),
(4,	'Daewoo',	'Kim Woo-choong',	1967,	'Seoul, South Korea'),
(5,	'Toyota Motor Corporation',	'Kiichiro Toyoda',	1937,	'Toyota City, Japan'),
(6,	'Alfa Romeo Automobiles S.p.A.',	'Ugo Stella',	1910,	'Turin, Piedmont, Italy'),
(7,	'Peugeot',	'Armand Peugeot',	1882,	'Ave de la Grande Arm�e, Paris'),
(8,	'Porsche AG',	'Ferdinand Porsche',	1931,	'Stuttgart, Germany');

