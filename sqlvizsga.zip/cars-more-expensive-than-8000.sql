SET ANSI_DEFAULTS ON

SELECT modelName FROM carsForSale WHERE acquisitionPrice > 8000;